/* Uros Bojanic
* 2019/0077
* i = 1
* j = 1
*/

#include <iostream>
#include <iomanip>
#include <climits>
#include <string>
#include <vector>
#include <unordered_set>
#include <queue>
#include <stack>
//#include <bits/stdc++.h>
using namespace std;

// Nodes are represented as strings, and edge weights as int
constexpr auto EMPTY_NODE = "";
constexpr int EMPTY_EDGE = INT_MAX;

class Graph {
private:
    int n;
    vector<string> nodes;
    vector<vector<int>> edges;
public:
    Graph(int dim);
    ~Graph() {}  /*  As we used vector from STL for dynamic arrays,
                    the appropriate destructor will be automatically called.*/
    void increase();
    void add_node(string node);
    int get_node_index(string node);
    void delete_node(string node);
    void add_edge(string node1, string node2, int weight);
    void delete_edge(string node1, string node2);
    void print_representation();
    // ADDITIONS
    void kruskal_algorithm();
    void floyd_algorithm();
    void BFS();
    void DFS();
};

Graph::Graph(int dim) {
    n = dim;
    nodes.resize(dim, EMPTY_NODE);
    edges.resize(dim, vector<int>(dim, EMPTY_EDGE));
}

void Graph::increase() {
    for (int i = 0; i < n; i++) {
        edges[i].push_back(EMPTY_EDGE);
    }
    n++;
    edges.push_back(vector<int>(n, EMPTY_EDGE));
    nodes.push_back(EMPTY_NODE);
}

void Graph::add_node(string node) {
    for (int i = 0; i < n; i++) {
        if (nodes[i] == EMPTY_NODE) {
            nodes[i] = node;
            edges[get_node_index(node)][get_node_index(node)] = 0;
            break;
        }
    }
}

int Graph::get_node_index(string node) {
    for (int i = 0; i < n; i++) {
        if (nodes[i] == node) {
            return i;
        }
    }
    return -1;
}

void Graph::delete_node(string node) {
    int ind = get_node_index(node);
    for (int i = 0; i < n; i++) {
        edges[i].erase(edges[i].begin() + ind);
    }
    edges.erase(edges.begin() + ind);
    n--;
    nodes.erase(nodes.begin() + ind);
}

void Graph::add_edge(string node1, string node2, int weight) {
    int node1_ind = get_node_index(node1);
    int node2_ind = get_node_index(node2);
    edges[node1_ind][node2_ind] = weight;
    edges[node2_ind][node1_ind] = weight;
}

void Graph::delete_edge(string node1, string node2) {
    add_edge(node1, node2, EMPTY_EDGE);
}

void Graph::print_representation() {
    cout << setw(4) << " ";
    for (int i = 0; i < n; i++) {
        cout << setw(4) << (nodes[i] == EMPTY_NODE ? "/" : nodes[i]);
    }
    cout << endl;
    for (int i = 0; i < n; i++) {
        cout << setw(4) << (nodes[i] == EMPTY_NODE ? "/" : nodes[i]);
        for (int j = 0; j < n; j++) {
            if (edges[i][j] < EMPTY_EDGE)
                cout << setw(4) << edges[i][j];
            else
                cout << setw(4) << "-";
        }
        cout << endl;
    }
    cout << endl;
    for (int i = 0; i < n; i++) {
        if (nodes[i] != "") {
            cout << "Node " << nodes[i] << " is connected to nodes: ";
            for (int j = 0; j < n; j++) {
                if (edges[i][j] < EMPTY_EDGE && i != j)
                    cout << nodes[j] << "(" << edges[i][j] << ") ";
            }
            cout << endl;
        }
    }
}

// ADDITIONS
void Graph::kruskal_algorithm() {
    priority_queue<pair<int, pair<int, int>>> all_edges;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (edges[i][j] != EMPTY_EDGE && i < j) {
                all_edges.push(make_pair(abs(edges[i][j]), make_pair(i, j)));
            }
        }
    }
    stack<pair<int, pair<int, int>>> sorted_edges;
    while (!all_edges.empty()) {
        sorted_edges.push(all_edges.top());
        all_edges.pop();
    }
    unordered_set<int> belonging_set;
    while (belonging_set.size() != n) {
        int weight = sorted_edges.top().first;
        int node_1 = sorted_edges.top().second.first;
        int node_2 = sorted_edges.top().second.second;
        cout << nodes[node_1] << "-" << nodes[node_2] << " (" << weight << ")" << endl;
        belonging_set.insert(node_1);
        belonging_set.insert(node_2);
        sorted_edges.pop();
    }
}

void Graph::floyd_algorithm() {
    vector<vector<int>> distances = edges;
    for (int k = 0; k < n; k++) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (distances[i][j] > distances[i][k] + distances[k][j]
                    && distances[i][k] < INT_MAX
                    && distances[k][j] < INT_MAX) {
                    distances[i][j] = distances[i][k] + distances[k][j];
                }
            }
        }
    }
    cout << "Distances between nodes:" << endl;
    cout << setw(4) << " ";
    for (int i = 0; i < n; i++) {
        cout << setw(4) << (nodes[i] == EMPTY_NODE ? "/" : nodes[i]);
    }
    cout << endl;
    for (int i = 0; i < n; i++) {
        cout << setw(4) << (nodes[i] == EMPTY_NODE ? "/" : nodes[i]);
        for (int j = 0; j < n; j++) {
            cout << setw(4) << distances[i][j];
        }
        cout << endl;
    }
}

void Graph::BFS() {
    // Initialization
    vector<bool> visited(n, false); 
    queue<int> q;
    // Choosing starting node
    int start_node = 0;
    q.push(start_node);
    visited[start_node] = true;
    // BFS
    while (!q.empty()) { 
        int next_node = q.front(); 
        cout << nodes[next_node] << " "; 
        q.pop(); 
        // Visit all neighbors of current node (push to queue)
        for (int i = 0; i < n; i++) { 
            if (edges[next_node][i] != EMPTY_EDGE && (!visited[i])) { 
                q.push(i); 
                visited[i] = true; 
            } 
        } 
    }
    cout << endl;
}

void Graph::DFS() {
    // Initialization
    vector<bool> visited(n, false); 
    stack<int> s;
    // Choosing starting node
    int start_node = 0;
    s.push(start_node);
    visited[start_node] = true;
    // DFS
    while (!s.empty()) { 
        int next_node = s.top(); 
        cout << nodes[next_node] << " "; 
        s.pop(); 
        // Visit all neighbors of current node (push to stack)
        for (int i = 0; i < n; i++) { 
            if (edges[next_node][i] != EMPTY_EDGE && (!visited[i])) { 
                s.push(i); 
                visited[i] = true; 
            } 
        } 
    }
    cout << endl;
}

///////////////////////////////////////////////////////////////////////////////////////////
/// User Interface Functions
///////////////////////////////////////////////////////////////////////////////////////////

void create_graph(Graph** graph) {
    if (*graph != nullptr) {
        cout << "Graph already exists!" << endl;
        return;
    }

    cout << "Creating graph... Enter graph size: ";
    int dim;
    cin >> dim;

    if (dim <= 0) {
        cout << "Invalid graph size input! Graph size must be a positive integer." << endl;
        return;
    }

    *graph = new Graph{ dim };
    cout << "Graph successfully created!" << endl;
}

void add_node(Graph* graph) {
    if (graph == nullptr) {
        cout << "Graph does not exist!" << endl;
        return;
    }

    cout << "Adding node..." << endl;
    cout << "Enter node name: ";
    string node;
    cin >> node;

    if (node.length() > 3) {
        cout << "Invalid node input! Node name must be a string no longer than 3 characters." << endl;
        return;
    }

    if (graph->get_node_index(node) != -1) {
        cout << "This node already exists!" << endl;
        return;
    }

    graph->add_node(node);

    if (graph->get_node_index(node) == -1) {
        cout << "No more free nodes in the graph!" << endl;
        cout << "Do you want to expand the graph? Enter 1(yes) or 0(no): ";
        int increase;
        cin >> increase;
        if (increase == 1) {
            graph->increase();
            graph->add_node(node);
        }
        else if (increase == 0) {
            return;
        }
        else {
            cout << "Invalid option choice." << endl;
            return;
        }
    }

    cout << "Node: " << node << " successfully added!" << endl;
}

void delete_node(Graph* graph) {
    if (graph == nullptr) {
        cout << "Graph does not exist!" << endl;
        return;
    }

    cout << "Deleting node... Enter node name: ";
    string node;
    cin >> node;

    if (graph->get_node_index(node) == -1) {
        cout << "Invalid node input! Node does not exist in the graph." << endl;
        return;
    }

    graph->delete_node(node);
    cout << "Node: " << node << " successfully deleted!" << endl;
}

void add_edge(Graph* graph, bool only_positive_weights) {
    if (graph == nullptr) {
        cout << "Graph does not exist!" << endl;
        return;
    }

    cout << "Adding edge..." << endl << "Enter first node: ";
    string node1, node2;
    cin >> node1;

    if (graph->get_node_index(node1) == -1) {
        cout << "Invalid node input! Node does not exist in the graph." << endl;
        return;
    }

    cout << "Enter second node: ";
    cin >> node2;

    if (graph->get_node_index(node2) == -1) {
        cout << "Invalid node input! Node does not exist in the graph." << endl;
        return;
    }

    int weight;
    cout << "Enter weight: ";
    cin >> weight;

    if (weight <= 0) {
        cout << "Invalid weight input! Weight must be a positive value." << endl;
        return;
    }

    if (!only_positive_weights) {
        cout << "Is the path built(1) or buildable(0)? Enter 1 or 0: ";
        int built;
        cin >> built;
        if (built == 0) {
            weight *= -1;
        }
        else if (built != 1) {
            cout << "Invalid option choice." << endl;
            return;
        }
    }

    graph->add_edge(node1, node2, weight);
    cout << "Nodes: " << node1 << " and " << node2 << " successfully connected! (" << abs(weight) << ")" << endl;
}

void delete_edge(Graph* graph) {
    if (graph == nullptr) {
        cout << "Graph does not exist!" << endl;
        return;
    }

    cout << "Deleting edge..." << endl;
    cout << "Enter first node: ";
    string node1, node2;
    cin >> node1;

    if (graph->get_node_index(node1) == -1) {
        cout << "Invalid node input! Node does not exist in the graph." << endl;
        return;
    }

    cout << "Enter second node: ";
    cin >> node2;

    if (graph->get_node_index(node2) == -1) {
        cout << "Invalid node input! Node does not exist in the graph." << endl;
        return;
    }

    graph->delete_edge(node1, node2);
    cout << "Nodes: " << node1 << " and " << node2 << " successfully 'disconnected'!" << endl;
}

void print_representation(Graph* graph) {
    if (graph == nullptr) {
        cout << "Graph does not exist!" << endl;
        return;
    }

    cout << "Printing graph representation..." << endl;
    graph->print_representation();
}

void delete_graph(Graph** graph) {
    if (*graph == nullptr) {
        cout << "Graph does not exist!" << endl;
        return;
    }

    cout << "Deleting graph..." << endl;
    delete* graph;
    *graph = nullptr;
    cout << "Graph successfully deleted!" << endl;
}

// ADDITIONS
void kruskal_algorithm(Graph* graph) {
    if (graph == nullptr) {
        cout << "Graph does not exist!" << endl;
        return;
    }

    cout << "Kruskal's algorithm..." << endl;
    graph->kruskal_algorithm();
}

void floyd_algorithm(Graph* graph) {
    if (graph == nullptr) {
        cout << "Graph does not exist!" << endl;
        return;
    }

    cout << "Floyd's algorithm..." << endl;
    graph->floyd_algorithm();
}

void BFS(Graph* graph) {
    if (graph == nullptr) {
        cout << "Graph does not exist!" << endl;
        return;
    }

    cout << "BFS search..." << endl;
    graph->BFS();
}

void DFS(Graph* graph) {
    if (graph == nullptr) {
        cout << "Graph does not exist!" << endl;
        return;
    }

    cout << "DFS search..." << endl;
    graph->DFS();
}

///////////////////////////////////////////////////////////////////////////////////////////
/// Main Program
///////////////////////////////////////////////////////////////////////////////////////////

int main()
{
    std::cout << "Program started..." << std::endl;
    Graph* graph = nullptr;
    bool exit_flag = false;

    while (!exit_flag) {
        cout << "--------------------------------------------" << endl;
        cout << "Select an option:" << endl;
        cout << "\t1. Create a graph" << endl;
        cout << "\t2. Add a node to the graph" << endl;
        cout << "\t3. Delete a node from the graph" << endl;
        cout << "\t4. Add an edge between two nodes" << endl;
        cout << "\t5. Delete an edge between two nodes" << endl;
        cout << "\t6. Print graph representation" << endl;
        cout << "\t7. Delete the graph" << endl;
        cout << "\t8. Kruskal's algorithm" << endl;
        cout << "\t9. Floyd's algorithm" << endl;
        cout << "\t10. BFS search" << endl;
        cout << "\t11. DFS search" << endl;
        cout << "\t0. Exit the program (EXIT)" << endl;
        cout << "Enter the desired number and press ENTER... ";
        

        int option;
        cin >> option;

        switch (option) {
        case 0:
            exit_flag = true;
            break;
        case 1:
            create_graph(&graph);
            break;
        case 2:
            add_node(graph);
            break;
        case 3:
            delete_node(graph);
            break;
        case 4:
            add_edge(graph, 1);
            break;
        case 5:
            delete_edge(graph);
            break;
        case 6:
            print_representation(graph);
            break;
        case 7:
            delete_graph(&graph);
            break;
        case 8:
            kruskal_algorithm(graph);
            break;
        case 9:
            floyd_algorithm(graph);
            break;
        case 10:
            BFS(graph);
            break;
        case 11:
            DFS(graph);
            break;
        default:
            cout << "Invalid option choice." << endl;
        }
    }

    delete graph;
    graph = nullptr;
    cout << endl << "Program finished.";

    return 0;
}