/* Uros Bojanic
* 2019/0077
* i = 1
* j = 1
*/

#include <iostream>
#include <iomanip>
#include <climits>
#include <string>
#include <algorithm>
#include <vector>
#include <queue>
#include <deque>
#include <utility>
#include <unordered_set>
//#include <bits/stdc++.h>
using namespace std;

// Nodes are represented as strings, and edge weights as int
constexpr auto EMPTY_NODE = "";
constexpr int EMPTY_EDGE = INT_MAX;
// ADDITION: Task 2. (2)
typedef priority_queue<pair<int, deque<int>>,vector<pair<int,deque<int>>>,greater<pair<int,deque<int>>>>& Paths;

class Graph {
private:
    int n;
    vector<string> nodes;
    vector<vector<int>> edges;
public:
    Graph(int dim);
    ~Graph() {}  /*  Since we used vector from STL for dynamic arrays,
                    the appropriate destructor will be called automatically.*/
    void increase();
    void add_node(string node);
    int get_node_index(string node);
    void delete_node(string node);
    void add_edge(string node1, string node2, int weight);
    void delete_edge(string node1, string node2);
    void print_representation();
    // ADDITION: Task 2. (1)
    bool check_node_existence();
    bool check_connectivity();
    int prims_algorithm();
    // ADDITION: Task 2. (2)
    void dijkstras_algorithm_print(Paths paths, deque<int>path, int start_node, vector<deque<int>> predecessor, int distance);
    void dijkstras_algorithm();
};

Graph::Graph(int dim) {
    n = dim;
    nodes.resize(dim, EMPTY_NODE);
    edges.resize(dim, vector<int>(dim, EMPTY_EDGE));
}

void Graph::increase() {
    for (int i = 0; i < n; i++) {
        edges[i].push_back(EMPTY_EDGE);
    }
    n++;
    edges.push_back(vector<int>(n, EMPTY_EDGE));
    nodes.push_back(EMPTY_NODE);
}

void Graph::add_node(string node) {
    for (int i = 0; i < n; i++) {
        if (nodes[i] == EMPTY_NODE) {
            nodes[i] = node;
            edges[get_node_index(node)][get_node_index(node)] = 0;
            break;
        }
    }
}

int Graph::get_node_index(string node) {
    for (int i = 0; i < n; i++) {
        if (nodes[i] == node) {
            return i;
        }
    }
    return -1;
}

void Graph::delete_node(string node) {
    int ind = get_node_index(node);
    for (int i = 0; i < n; i++) {
        edges[i].erase(edges[i].begin() + ind);
    }
    edges.erase(edges.begin() + ind);
    n--;
    nodes.erase(nodes.begin() + ind);
}

void Graph::add_edge(string node1, string node2, int weight) {
    int node1_ind = get_node_index(node1);
    int node2_ind = get_node_index(node2);
    edges[node1_ind][node2_ind] = weight;
    edges[node2_ind][node1_ind] = weight;
}

void Graph::delete_edge(string node1, string node2) {
    add_edge(node1, node2, EMPTY_EDGE);
}

void Graph::print_representation() {
    cout << setw(4) << " ";
    for (int i = 0; i < n; i++) {
        cout << setw(4) << (nodes[i] == EMPTY_NODE ? "/" : nodes[i]);
    }
    cout << endl;
    for (int i = 0; i < n; i++) {
        cout << setw(4) << (nodes[i] == EMPTY_NODE ? "/" : nodes[i]);
        for (int j = 0; j < n; j++) {
            if (edges[i][j] < EMPTY_EDGE)
                cout << setw(4) << abs(edges[i][j]);
            else
                cout << setw(4) << "-";
        }
        cout << endl;
    }
    cout << endl;
    for (int i = 0; i < n; i++) {
        if (nodes[i] != "") {
            cout << "Node " << nodes[i] << " is connected to nodes: ";
            for (int j = 0; j < n; j++) {
                if (edges[i][j] < EMPTY_EDGE && i != j)
                    cout << nodes[j] << "(" << abs(edges[i][j]) << ") ";
            }
            cout << endl;
        }
    }
}

// ADDITION: Task 2. (1)
bool Graph::check_node_existence() {
    for (int i = 0; i < n; i++) {
        if (nodes[i] == "") {
            return 0;
        }
    }
    return 1;
}

bool Graph::check_connectivity() {
    int start_node = 0;
    unordered_set<int> visited;
    visited.insert(start_node);
    queue<int> next_nodes;
    next_nodes.push(start_node);
    while(!next_nodes.empty()) {
        int node2 = next_nodes.front();
        next_nodes.pop();
        for(int node1 = 0; node1 < n; node1++) {
            if(edges[node1][node2] != EMPTY_EDGE && visited.count(node1) == 0) {
                visited.insert(node1);
                next_nodes.push(node1);
            }
        }
    }
    if (visited.size() == n) {
        return 1;
    }
    return 0;
}

int Graph::prims_algorithm() {
    // Initialization
    vector<int> predecessor(n, INT_MAX);
    vector<int> distance(n, INT_MAX);
    unordered_set<int> visited;
    // Determining the starting node (randomly)
    int start_node = rand() % n;
    distance[start_node] = 0;
    predecessor[start_node] = -1;
    // Prim's algorithm
    for (int edge = 1; edge < n; edge++) {
        // Select unvisited node with minimum distance
        int node1 = -1;
        int min_distance = INT_MAX;
        for (int i = 0; i < n; i++) {
            if (visited.count(i) == 0 && distance[i] < min_distance) {
                node1 = i;
                min_distance = distance[i];
            }
        }
        // Visit it
        visited.insert(node1);
        for (int node2 = 0; node2 < n; node2++) {
            if (visited.count(node2) == 0 && edges[node1][node2] < distance[node2]) {
                predecessor[node2] = node1;
                distance[node2] = edges[node1][node2];
            }
        }
    }
    // Print solution
    int cost = 0;
    for (int node2 = 0; node2 < n; node2++) {
        if (node2 != start_node) {
            int node1 = predecessor[node2];
            cout << "Metro line " << node2 + 1 << ": " << nodes[node1] << "-" << nodes[node2] << " (" << edges[node1][node2] << ")" << endl;
            cost += edges[node1][node2];
        }
    }
    return cost;
}

// ADDITION: Task 2. (2)
void Graph::dijkstras_algorithm_print(Paths paths, deque<int>path, int start_node, vector<deque<int>> predecessor, int distance) {
    int current_node = path.back();
    if (current_node == start_node) {
        int total_distance = 0, build_count = 0;
        for (int i = path.size() - 1; i > 0; i--) {
            total_distance += abs(edges[path[i]][path[i-1]]);
            build_count += edges[path[i]][path[i-1]] < 0;
        }
        if (total_distance == distance) {
            paths.push(make_pair(build_count, path));
        }
    }
    else {
        deque<int>new_path = path;
        vector<deque<int>> new_predecessor = predecessor;
        while (!new_predecessor[current_node].empty()) {
            new_path.push_back(new_predecessor[current_node].front());
            new_predecessor[current_node].pop_front();
            dijkstras_algorithm_print(paths, new_path, start_node, new_predecessor, distance);
            new_path.pop_back();
        }
    }
}

void Graph::dijkstras_algorithm() {
    // Initialization
    vector<deque<int>> predecessor(n);
    vector<int> distance(n, INT_MAX);
    unordered_set<int> visited;
    // Determining the start node (fire station)
    int start_node = get_node_index("V");
    distance[start_node] = 0;
    predecessor[start_node].push_front(-1);
    // Dijkstra's algorithm
    for (int edge = 1; edge < n; edge++) {
        // Select unvisited node with minimum distance
        int node1 = -1;
        int min_distance = INT_MAX;
        for (int i = 0; i < n; i++) {
            if (visited.count(i) == 0 && distance[i] < min_distance) {
                node1 = i;
                min_distance = distance[i];
            }
        }
        // Visit it
        visited.insert(node1);
        for (int node2 = 0; node2 < n; node2++) {
            if (visited.count(node2) == 0 && edges[node1][node2] < INT_MAX && distance[node1] != INT_MAX && distance[node1] + abs(edges[node1][node2]) < distance[node2]) {
                predecessor[node2].push_front(node1);
                distance[node2] = distance[node1] + abs(edges[node1][node2]);
            }
            else if (visited.count(node2) == 0 && edges[node1][node2] < INT_MAX && distance[node1] != INT_MAX && distance[node1] + abs(edges[node1][node2]) == distance[node2]) {
                predecessor[node2].push_back(node1);
            }
        }
    }
    // Print solution
    for (int end_node = 0; end_node < n; end_node++) {
        priority_queue<pair<int, deque<int>>, vector<pair<int, deque<int>>>, greater<pair<int, deque<int>>>> paths;
        if (end_node != start_node) {
            cout << "Paths to node " << nodes[end_node] << ":" << endl;
            deque<int>path;
            path.push_back(end_node);
            dijkstras_algorithm_print(paths, path, start_node, predecessor, distance[end_node]);
        }
        while(!paths.empty()){
            cout << "\t";
            for (int i = paths.top().second.size() - 1; i > 0; i--) {
                cout << nodes[paths.top().second[i]] << "-";
            }
            cout << nodes[paths.top().second[0]] << endl << "\tPath length: " << distance[end_node] << " (Required road constructions: " << paths.top().first << ")" << endl;
            paths.pop();
        }
    }
}

///////////////////////////////////////////////////////////////////////////////////////////
/// User interface functions
///////////////////////////////////////////////////////////////////////////////////////////

void create_graph(Graph** graph) {
    if (*graph != nullptr) {
        cout << "Graph already exists!" << endl;
        return;
    }

    cout << "Creating graph... Enter graph size: ";
    int dim;
    cin >> dim;

    if (dim <= 0) {
        cout << "Invalid graph size input! Graph size must be a positive integer." << endl;
        return;
    }

    *graph = new Graph{ dim };
    cout << "Graph successfully created!" << endl;
}

void add_node(Graph* graph) {
    if (graph == nullptr) {
        cout << "Graph does not exist!" << endl;
        return;
    }

    cout << "Adding node..." << endl;
    cout << "Enter node name: ";
    string node;
    cin >> node;

    if (node.length() > 3) {
        cout << "Invalid node input! Node name must be a string no longer than 3 characters." << endl;
        return;
    }

    if (graph->get_node_index(node) != -1) {
        cout << "That node already exists!" << endl;
        return;
    }

    graph->add_node(node);

    if (graph->get_node_index(node) == -1) {
        cout << "No more free nodes in the graph!" << endl;
        cout << "Do you want to expand the graph? Enter 1(yes) or 0(no): ";
        int increase;
        cin >> increase;
        if (increase == 1) {
            graph->increase();
            graph->add_node(node);
        }
        else if (increase == 0) {
            return;
        }
        else {
            cout << "Invalid option choice." << endl;
            return;
        }
    }

    cout << "Node: " << node << " successfully added!" << endl;
}

void delete_node(Graph* graph) {
    if (graph == nullptr) {
        cout << "Graph does not exist!" << endl;
        return;
    }

    cout << "Deleting node... Enter node name: ";
    string node;
    cin >> node;

    if (graph->get_node_index(node) == -1) {
        cout << "Invalid node input! Node does not exist in the graph." << endl;
        return;
    }

    graph->delete_node(node);
    cout << "Node: " << node << " successfully deleted!" << endl;
}

void add_edge(Graph* graph, bool only_positive_weights) {
    if (graph == nullptr) {
        cout << "Graph does not exist!" << endl;
        return;
    }

    cout << "Adding edge..." << endl << "Enter first node: ";
    string node1, node2;
    cin >> node1;

    if (graph->get_node_index(node1) == -1) {
        cout << "Invalid node input! Node does not exist in the graph." << endl;
        return;
    }

    cout << "Enter second node: ";
    cin >> node2;

    if (graph->get_node_index(node2) == -1) {
        cout << "Invalid node input! Node does not exist in the graph." << endl;
        return;
    }

    int weight;
    cout << "Enter weight: ";
    cin >> weight;

    if (weight <= 0) {
        cout << "Invalid weight input! Weight must be a positive value." << endl;
        return;
    }

    if (!only_positive_weights) {
        cout << "Is the road built(1) or buildable(0)? Enter 1 or 0: ";
        int built;
        cin >> built;
        if (built == 0) {
            weight *= -1;
        }
        else if (built != 1) {
            cout << "Invalid option choice." << endl;
            return;
        }
    }

    graph->add_edge(node1, node2, weight);
    cout << "Nodes: " << node1 << " and " << node2 << " successfully connected! (" << abs(weight) << ")" << endl;
}

void delete_edge(Graph* graph) {
    if (graph == nullptr) {
        cout << "Graph does not exist!" << endl;
        return;
    }

    cout << "Deleting edge..." << endl;
    cout << "Enter first node: ";
    string node1, node2;
    cin >> node1;

    if (graph->get_node_index(node1) == -1) {
        cout << "Invalid node input! Node does not exist in the graph." << endl;
        return;
    }

    cout << "Enter second node: ";
    cin >> node2;

    if (graph->get_node_index(node2) == -1) {
        cout << "Invalid node input! Node does not exist in the graph." << endl;
        return;
    }

    graph->delete_edge(node1, node2);
    cout << "Nodes: " << node1 << " and " << node2 << " successfully 'disconnected'!" << endl;
}

void print_representation(Graph* graph) {
    if (graph == nullptr) {
        cout << "Graph does not exist!" << endl;
        return;
    }

    cout << "Printing graph representation..." << endl;
    graph->print_representation();
}

void delete_graph(Graph** graph) {
    if (*graph == nullptr) {
        cout << "Graph does not exist!" << endl;
        return;
    }

    cout << "Deleting graph..." << endl;
    delete* graph;
    *graph = nullptr;
    cout << "Graph successfully deleted!" << endl;
}

// ADDITION: Task 2. (1)
void prims_algorithm(Graph* graph) {
    if (graph == nullptr) {
        cout << "Graph does not exist!" << endl;
        return;
    }

    if (!graph->check_node_existence()) {
        cout << "Nodes are not initialized! There are empty nodes in the graph." << endl;
        return;
    }

    if (!graph->check_connectivity()) {
        cout << "Graph is not connected! Prim's algorithm only works on connected graphs." << endl;
        return;
    }

    cout << "Prim's algorithm..." << endl;
    int metro_cost = graph->prims_algorithm();
    cout << "Total cost of metro construction: " << metro_cost << "." << endl;
}

// ADDITION: Task 2. (2)
void dijkstras_algorithm(Graph* graph) {
    if (graph == nullptr) {
        cout << "Graph does not exist!" << endl;
        return;
    }

    if (!graph->check_node_existence()) {
        cout << "Nodes are not initialized! There are empty nodes in the graph." << endl;
        return;
    }

    if (!graph->check_connectivity()) {
        cout << "Graph is not connected! Dijkstra's algorithm only works on connected graphs." << endl;
        return;
    }

    if(graph->get_node_index("V") == -1) {
        cout << "Graph does not contain node V (fire station)!" << endl;
        return;
    }

    cout << "Dijkstra's algorithm..." << endl;
    graph->dijkstras_algorithm();
}

///////////////////////////////////////////////////////////////////////////////////////////
/// Main program operation modes
///////////////////////////////////////////////////////////////////////////////////////////

void mode1_metro() {
    Graph* graph = nullptr;
    bool exit_flag = false;

    while (!exit_flag) {
        cout << "--------------------------------------------" << endl;
        cout << "Choose an option:" << endl;
        cout << "\t1. Create city (graph)" << endl;
        cout << "\t2. Add location (node) to city (graph)" << endl;
        cout << "\t3. Delete location (node) from city (graph)" << endl;
        cout << "\t4. Add metro line (edge) between two locations (nodes)" << endl;
        cout << "\t5. Delete metro line (edge) between two locations (nodes)" << endl;
        cout << "\t6. Print city representation (graph)" << endl;
        cout << "\t7. Delete city (graph)" << endl;
        cout << "\t8. Calculate metro construction cost (Prim's algorithm)" << endl;
        cout << "\t0. Return to main menu (BACK)" << endl;
        cout << "Enter desired number and press ENTER... ";

        int option;
        cin >> option;

        switch (option) {
        case 0:
            exit_flag = true;
            break;
        case 1:
            create_graph(&graph);
            break;
        case 2:
            add_node(graph);
            break;
        case 3:
            delete_node(graph);
            break;
        case 4:
            add_edge(graph, 1);
            break;
        case 5:
            delete_edge(graph);
            break;
        case 6:
            print_representation(graph);
            break;
        case 7:
            delete_graph(&graph);
            break;
        case 8:
            prims_algorithm(graph);
            break;
        default:
            cout << "Invalid option choice." << endl;
        }
    }

    delete graph;
    graph = nullptr;
    return;
}

void mode2_firefighters() {
    Graph* graph = nullptr;
    bool exit_flag = false;

    while (!exit_flag) {
        cout << "--------------------------------------------" << endl;
        cout << "Choose an option:" << endl;
        cout << "\t1. Create city (graph)" << endl;
        cout << "\t2. Add location (node) to city (graph)" << endl;
        cout << "\t3. Delete location (node) from city (graph)" << endl;
        cout << "\t4. Add road (existing or buildable) between two locations (nodes)" << endl;
        cout << "\t5. Delete road (existing or buildable) between two locations (nodes)" << endl;
        cout << "\t6. Print city representation (graph)" << endl;
        cout << "\t7. Delete city (graph)" << endl;
        cout << "\t8. Calculate shortest paths from fire station to all locations" << endl;
        cout << "\t0. Return to main menu (BACK)" << endl;
        cout << "Enter desired number and press ENTER... ";

        int option;
        cin >> option;

        switch (option) {
        case 0:
            exit_flag = true;
            break;
        case 1:
            create_graph(&graph);
            break;
        case 2:
            add_node(graph);
            break;
        case 3:
            delete_node(graph);
            break;
        case 4:
            add_edge(graph, 0);
            break;
        case 5:
            delete_edge(graph);
            break;
        case 6:
            print_representation(graph);
            break;
        case 7:
            delete_graph(&graph);
            break;
        case 8:
            dijkstras_algorithm(graph);
            break;
        default:
            cout << "Invalid option choice." << endl;
        }
    }

    delete graph;
    graph = nullptr;
    return;
}

///////////////////////////////////////////////////////////////////////////////////////////
/// Main program
///////////////////////////////////////////////////////////////////////////////////////////

int main()
{
    int option = 1;
    while(option != 0) {
        cout << "--------------------------------------------" << endl;
        cout << "Choose program operation mode:" << endl;
        cout << "\t1. Create and display metro" << endl;
        cout << "\t2. Find shortest path for fire trucks" << endl;
        cout << "\t0. Exit program (EXIT)" << endl;
        cout << "Enter desired number and press ENTER... ";
        cin >> option;
        switch (option) {
        case 0:
            break;
        case 1:
            mode1_metro();
            break;
        case 2:
            mode2_firefighters();
            break;
        default:
            cout << "Invalid option choice." << endl;
        }
    }
    
    cout << "Program finished.";
    return 0;
}